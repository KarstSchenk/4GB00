function dhdt = ODESystem(~,h)                                                          %Creates function to make differebtial equation
global h_p2
global APipe ASupp AStor hDump                                                          %Retrieves global variables
global Q1 Q4                                                                            %Retrieves global variables
global dh rPipe                                                                         %Retrieves global variables
global L zeta rho mu                                                                    %Retrieves global variables
global V2 V3 V4                                                                         %Retrieves global variables
global vis kom                                                                          %Retreives global variables
global Re_offset

Re2 = ((abs(V2(end))*rho*2*rPipe)/mu)+Re_offset;                                        %Calculates Reynolds number with previous velocity
Re3 = ((abs(V3(end))*rho*2*rPipe)/mu)+Re_offset;                                        %Calculates Reynolds number with previous velocity

if h(1) <= h_p2                                                                         %Determines values to be entered in AreaFunc      
    if h(2) <= h_p2
        A2 = 0;
    elseif h(2) >= h_p2+2*rPipe
        A2 = AreaFunc(h(2));
    else
        A2 = AreaFunc(h(2));
    end
elseif h(1) >= h_p2+2*rPipe
    if h(2) <= h_p2 
        A2 = AreaFunc(h(1));
    elseif h(2) >= h_p2+2*rPipe
        A2 = pi*rPipe^2;
    else
        A2 = pi*rPipe^2;
    end
else
    if h(2) <= h_p2
        A2 = AreaFunc(h(1));
    elseif h(2) >= h_p2+2*rPipe
        A2 = pi*rPipe^2;
    else
        A2 = pi*rPipe^2;
    end
end

if h(1)>=h_p2                                                                           %Determines values to be entered in Bernoulli
    if h(1)>=h(2)
        if h(2)>=h_p2
            v2 = Bernoulli_losses([h(1) h(2)], L(1), zeta(1), Re2);
        else
            v2 = Bernoulli_losses([h(1) h_p2], L(1), zeta(1), Re2);
        end
    else
        if h(2)>=h_p2
            v2 = Bernoulli_losses([h(1) h(2)], L(1), zeta(1), Re2);
        else
            v2 = 0;
        end
    end 
else
    if h(1)>=h(2)
        if h(2)>=h_p2
            v2 = 0;
        else
            v2 = Bernoulli_losses([h(1) h(2)], L(1), zeta(1), Re2);
        end
    else
        if h(2)>=h_p2
            v2 = Bernoulli_losses([h_p2 h(2)], L(1), zeta(1), Re2);
        else
            v2 = 0;
        end
    end   
end

Q2 = v2*A2;                                                                             %Calculates flow rate trough pipe 2

if h(2)>h(1) && h(2)>dh
    v3 = Bernoulli_losses([h(2) h(1)], L(2), zeta(2), Re3);                             %Retrieves result of Bernoulli with losses for v3
else
    v3 = 0;                                                                             %No return valve
end
Q3 = v3*pi*rPipe^2;                                                                     %Calculates flow rate through pipe 3
Q5 = Leaks(h(1));

V2=[V2 v2];                                                                             %Creates an araay of velocities that is always accesible
V3=[V3 v3];                                                                             %Creates an araay of velocities that is always accesible
vis=[vis Re2];                                                                          %Sets which non-global variables we would like to see
kom = [kom Re3];                                                                        
dhdt = [(Q1-Q2+Q3-Q4-Q5)/ASupp                                                          %Differential equation for supply tank
    ((Q2-Q3)/AStor)];                                                                   %Differential equation for storage tank

if h(1)<0                                                                               %Sets bottom value for supply tank
    dhdt(1) = 0;                                                                        %Water level can not decrease further
end

if h(2)>hDump                                                                           %If water level in storage tank is higher than dump pipe
    Re4 = ((abs(V4(end))*rho*2*rPipe)/mu)+Re_offset;                                    %Calculates Reynolds number for drain pipe
    dhdt(2)= dhdt(2)+Bernoulli_losses([hDump h(2)],0,0.5,Re4)*APipe/AStor;             %Sets dhdt equal to zero when hSupp > hDump
    V4=[V4 dhdt(2)];
end

end
