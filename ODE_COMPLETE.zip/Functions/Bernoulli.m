function v = Bernoulli(h)                                                               %Creates function to calculate velocity of flow with Bernoulli
    global g;                                                                           %Retrieves global variables
    if h(1)>h(2)                                                                        %Determines on which side the water level is higher
        i = 1;                                                                          %Changes sign to avoid negative square roots
    else
        i = -1;                                                                         %Changes sign to avoid negative square roots
    end
    v = i*sqrt(i*2*g*(h(1)-h(2)));                                                      %Calculates velocity through pipe 2 and 3
end