tic                                             %Closes all plots and clears all variable
addpath('functions')                                                                    %Lets this script find other scripts one folder deeper
global rPipe; rPipe = 9.5e-3;                                                           %Declares all variables that have to do with Radii
global h_p2 dh hDump; h_p2 = 0.255; dh = 0.11; hDump=0.27;                               %Declares all variables that have to do with Heights
global APipe ASupp AStor; APipe = 2.83529e-4; ASupp = 1.606061e-2; AStor = 6.834928e-2; %Declares all variables that have to do with Area's
global Q1 Q4; Q1 = 0.0001996; Q4 = 0;                                                   %Declares all variables that have to do with Flow rates
global V2 V3 V4                                                                         %Declares variables for velocity 2 and 3 (Upper case V to avoid confusion)
global vis kom                                                                          %Declares two variables which can be used to view non-global variables
vis=[]; kom=[];                                                                         %Creates two empty arrays
global g; g = 9.81;                                                                     %Declares all variables that have to do with gravity
global rho mu; rho = 998; mu = 1e-3;                                                    %Declares all variables that have to do with fluid properties
global L zeta k; L = [0.310;0.510]; zeta = [1.5;1.3]; k = 1e-5;                         %Declares all variables that have to do with friction and losses
global Re_offset; Re_offset = 3;
h0 = [0; 0.11];                                                                         %Declares initial height of supply and storage vessel

V2=Bernoulli(h0); V3=Bernoulli([h0(2) h0(1)]); V4=Bernoulli([hDump h0(2)]);             %Finds initial values for velocities to calculate Reynolds

tspan=[0 200];                                                                          %Declares time span for calculations
t=0;tout=[];hout=[];                                                                    %Declares new variables for refinement loop
refine = 4;                                                                             %Sets number of steps to go back and refine
options = odeset('Events',@event, 'OutputSel',1,...                                     %Declares setting for refinement
    'Refine',refine);
flip=false;                                                                             %Creates variable 'flip' to prevents script from going backwards

while t<tspan(2)                                                                        %Creates loop that refines the graph around a certain value
    [t,h] = ode45(@ODESystem, tspan, h0, options);                                      %Declares solver and solves ODE
    if ~flip                                                                            %If flip is false
        refine=2*refine;                                                                %Doubles refine value
        flip=true;                                                                      %Sets flip is true
    else
        refine=refine/2;                                                                %Halves refine value
        flip=false;                                                                     %Sets flip is false
    end
    
    options = odeset(options,'InitialStep',t(length(t))-t(length(t)-refine));       
    h0=h(end,:);                                                                        %Declares new initial condition
    tout=[tout;t];                                                                      %Declares output t from refinement loop
    hout=[hout;h];                                                                      %Declares output h from refinement loop
    tspan(1)=t(end);                                                                    %Declares new tspan with same t(end)
end

plot(tout,hout)                                                                         %Plots results
ylim([0 max(max(hout))+0.05])                                                           %Sets y limits
legend('hSupp','hStor');                                                                %Creates legend
xlabel('Time [s]'); ylabel('Height of water level [m]')                                 %Adds labels
title('Water level in both tanks as a function of time')                                %Adds title

toc

function [value,isterminal,direction]= event(~,h)                                       %Creates function which states when refinement loops starts
global hDump                                                                            %Retrieves global variable
value= [h(2)- hDump ; h(2)-h(1)];                                                       %Value you want to be zero             
isterminal = [1 ; 1];                                                                   %Stop integration?
direction = [0 ; 0];                                                                    %Direction of approach
end