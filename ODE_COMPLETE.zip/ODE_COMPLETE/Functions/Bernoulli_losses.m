function v = Bernoulli_losses(h,L,zeta,Re)                                              %Creates function to calculate velocity of flow with Bernoulli with losses
global g rPipe;                                                                         %Retrieves global variables
global k

if h(1) < h(2)                                                                          %Determines which tank has a higher water leve;
    i = -1;                                                                             %Changes sign to avoid negative square roots
else
    i = 1;                                                                              %Changes sign to avoid negative square roots
end

if Re > 4000
    lambda = 0.25/(log10((k/(3.71*2*rPipe))+5.74/(Re^0.9)))^2;                          %Calculates Darcy friction coefficient for turbulent flow
elseif Re < 2300
    lambda= 64/Re;                                                                      %Calculates Darcy friction coefficient for laminar flow
else
    lambda1 = 0.25/(log10((k/(3.71*2*rPipe))+5.74/(Re^0.9)))^2;                         %Calculates Darcy friction coefficient for turbulent flow
    lambda2 = 64/Re;                                                                    %Calculates Darcy friction coefficient for lamiar flow
    lambda = (lambda1*(Re-2000)-lambda2*(Re-4000))/(4000-2000);                         %Interpolates to find Lambda in transient region
end
v = i*sqrt((2*g*i*(h(1)-h(2)))/(1+(lambda*L/(2*rPipe))+zeta));                          %Calculates velocity
end