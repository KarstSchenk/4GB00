function A2= AreaFunc(h)                                                                %Creates funcion to calculate area of pipe 2
global rPipe h_p2                                                                       %Retrieves global variables
func_A2 = @(y) sqrt(rPipe^2-(y-(h_p2+rPipe)).^2);                                       %Declares function for area calculation
A2 = real(2*integral(func_A2,0,h));                                                     %Calculates area of pipe 2 for each index
end